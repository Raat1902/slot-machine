
import java.util.*;

public class SlotMachine {
    static final String[] SYMBOLS = {"@", "#", "$", "&", "*"};
    static Random rand = new Random();

    public static void main(String[] args) throws InterruptedException {
        Scanner sc = new Scanner(System.in);
        int balance = 100;
        System.out.println("=== JAVA SLOT MACHINE ===");
        System.out.println("You start with $" + balance);

        while (true) {
            System.out.print("\nPress ENTER to spin ($10) or type 'q' to quit: ");
            String input = sc.nextLine();
            if (input.equalsIgnoreCase("q")) break;

            if (balance < 10) {
                System.out.println("Not enough money to play. Game over!");
                break;
            }

            balance -= 10;
            String[] result = spinReels();
            animateSpin(result);

            if (isWin(result)) {
                int payout = 40 + rand.nextInt(30); // $40–$69 random win
                balance += payout;
                System.out.println(">>> WINNER! You earned $" + payout);
            } else {
                System.out.println("No match. You lost $10.");
            }

            System.out.println("Current Balance: $" + balance);
        }

        System.out.println("\nThanks for playing!");
        sc.close();
    }

    static String[] spinReels() {
        String[] result = new String[3];
        for (int i = 0; i < 3; i++) {
            result[i] = SYMBOLS[rand.nextInt(SYMBOLS.length)];
        }
        return result;
    }

    static void animateSpin(String[] result) throws InterruptedException {
        System.out.print("Spinning");
        for (int i = 0; i < 3; i++) {
            Thread.sleep(250);
            System.out.print(".");
        }
        System.out.println();

        Thread.sleep(300);
        System.out.println("[ " + result[0] + " | " + result[1] + " | " + result[2] + " ]");
    }

    static boolean isWin(String[] r) {
        return r[0].equals(r[1]) && r[1].equals(r[2]);
    }
}
